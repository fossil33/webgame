using Newtonsoft.Json;
using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using static APIManager;

public class MarketAPI
{

    private MonoBehaviour coroutineRunner;
    private string userId;

    // �����ڸ� ���� MonoBehaviour �ν��Ͻ��� ���Թ޽��ϴ�.
    public MarketAPI(MonoBehaviour runner, string userId)
    {
        this.userId = userId;
        this.coroutineRunner = runner;
    }

    //�Ǹ� ��� ��������
    IEnumerator GetSellingList()
    {
        string url = $"{APIConstants.BASE_API_URL}/market/items";
        using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
        {
            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    IMarketItemResponse[] responseList = JsonConvert.DeserializeObject<IMarketItemResponse[]>(webRequest.downloadHandler.text);
                    foreach (var response in responseList)
                    {
                        APIEvents.OnGetSellingListSuccess?.Invoke(response);
                    }
                }
                catch (JsonException ex)
                {
                    Debug.LogError("JSON ������ȭ ����: " + ex.Message);
                }
            }
            else
            {
                Debug.LogError(webRequest.downloadHandler);
            }
        }
    }


    IEnumerator GetSellingList(string id)
    {
        string url = $"{APIConstants.BASE_API_URL}/market/items/{id}";

        using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
        {
            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    IMarketItemResponse[] responseList = JsonConvert.DeserializeObject<IMarketItemResponse[]>(webRequest.downloadHandler.text);
                    foreach (var response in responseList)
                    {
                        Debug.Log($"{response}");
                        APIEvents.OnGetMySellingListSuccess?.Invoke(response);
                    }
                }
                catch (JsonException ex)
                {
                    Debug.LogError("JSON ������ȭ ����: " + ex.Message);
                }
            }
        }
    }

    //�Ǹ� ��û
    IEnumerator RequestToSell(int ItemId, ItemSpec spec, string price, string count)
    {
        var itemData = new
        {
            userId = userId,
            ItemId = ItemId,
            itemSpec = spec,
            price = price,
            itemCount = count
        };
        string json = JsonConvert.SerializeObject(itemData);


        string url = $"{APIConstants.BASE_API_URL}/market/items";  // ������ ��� ��� url�����ؾߵ�.

        using (UnityWebRequest webRequest = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            webRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
            webRequest.downloadHandler = new DownloadHandlerBuffer();
            webRequest.SetRequestHeader("Content-Type", "application/json");

            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("���� ���� ����!");
                string responseJson = webRequest.downloadHandler.text;
                try
                {
                    ItemRegistResponse response = JsonConvert.DeserializeObject<ItemRegistResponse>(responseJson);

                    if (response.success)
                    {
                        APIEvents.OnItemRegister?.Invoke(response);
                    }
                }
                catch { }
            }
            else
            {
                Debug.LogError("������ ��� ����: " + webRequest.error);
            }
        }

    }

    // ���� ��û
    IEnumerator RequestToBuy(int marketId, string count)
    {
        string url = $"{APIConstants.BASE_API_URL}/market/buy?userId={userId}&marketId={marketId}&count={count}";

        using (UnityWebRequest webRequest = new UnityWebRequest(url, "GET"))
        {
            webRequest.downloadHandler = new DownloadHandlerBuffer();

            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("���� ���� ����!");
                string responseJson = webRequest.downloadHandler.text;
                try
                {
                    BuyItemResponse response = JsonConvert.DeserializeObject<BuyItemResponse>(responseJson);

                    if (response.success)
                    {
                        APIEvents.OnBuyItem?.Invoke(response);
                    }
                }
                catch (JsonException ex)
                {
                    Debug.LogError("JSON ������ȭ ����" + ex.Message);
                }
            }
            else
            {
                Debug.LogError("���� ��� ���");
            }
        }
    }

    //������ ��� ���
    IEnumerator CancelRegistItem(int marketId)
    {
        string url = $"{APIConstants.BASE_API_URL}/market/items/{userId}/{marketId}";

        using (UnityWebRequest webRequest = UnityWebRequest.Delete(url))
        {
            webRequest.downloadHandler = new DownloadHandlerBuffer();

            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("������ ���� ��û ����");
                string responseJson = webRequest.downloadHandler.text;
                try
                {
                    CancelRegistResponse response = JsonConvert.DeserializeObject<CancelRegistResponse>(responseJson);
                    if (response.success)
                    {
                        APIEvents.OnCancelItem?.Invoke(response);
                    }
                }
                catch (JsonException ex)
                {
                    Debug.LogError($"������ȭ ���� : {ex.Message}");
                }
            }
            else
            {
                Debug.LogError($"������ ���� ����: {webRequest.result}");
            }
        }
    }


    //������ ��� �������� ��û
    public void RequestToGetSellingList()
    {
        coroutineRunner.StartCoroutine(GetSellingList());
    }
    public void RequestToGetMyList()
    {
        coroutineRunner.StartCoroutine(GetSellingList(userId));
    }

    //������ ���� ��û
    public void RequestToBuyItem(int marketId, string count)
    {
        coroutineRunner.StartCoroutine(RequestToBuy(marketId, count));
    }

    //������ �Ǹ� ��û
    public void RequestToSellItem(int Itemid, ItemSpec itemspec, string price, string count)
    {
        coroutineRunner.StartCoroutine(RequestToSell(Itemid, itemspec, price, count));
    }

    //������ ��� ��� ��û
    public void RequestToCancelItem(int marketId)
    {
        coroutineRunner.StartCoroutine(CancelRegistItem(marketId));
    }
}




public class IMarketItemResponse
{
    public int marketId { get; set; }  //���� id
    public int ItemId { get; set; }     //������ id
    public int ItemCount { get; set; }  // ��ϵ� ������ ����
    public int price { get; set; }   //����� ����
}


public class ItemRegistResponse : IMarketItemResponse
{
    public bool success;  //��� ���� ����
    public string message { get; set; }  // ���� or ���� �޼���
}

public class CancelRegistResponse : IMarketItemResponse
{
    public bool success;
    public string message { get; set; }
    public ItemSpec spec { get; set; }
}


public class BuyItemResponse
{
    public bool success;
    public string message { get; set; }
    public int marketId { get; set; }
    public int ItemId { get; set; }
    public ItemSpec spec { get; set; }
    public int purchasedItemCount { get; set; }
    public int remainingItemCount { get; set; }
    public int gold { get; set; }
}




