
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

public class APIManager : MonoBehaviour
{
#if UNITY_WEBGL
    [DllImport("__Internal")]
    private static extern void MySignalReady();
#endif

    public static APIManager Instance { get; private set; }
    public PlayerDataAPI PlayerData;
    public MarketAPI Market;
    public InventoryAPI Inventory;
    public QuestAPI Quest;
    public DialogueAPI Dialogue;
    public LoginData loginData;



    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }

    }

    public void Start()
    {
#if UNITY_WEBGL
        //MySignalReady();
        //Debug.Log("Unity -> ��: �غ� �Ϸ� ��ȣ ����");
#endif


#if UNITY_EDITOR
        LoginData testData = new LoginData { user_id = "editor_user_id2", nickname = "������_�׽���" };
        Debug.Log("�����ͷ� ����");
        ReceiveLoginData(JsonConvert.SerializeObject(testData));
#endif


    }


    //�α��� ������ �ޱ�
    public void ReceiveLoginData(string loginJson)
    {
        Debug.Log("�����κ��� �α��� ������ ����: " + loginJson);

        //JSON ���ڿ��� �Ľ�
        loginData = JsonConvert.DeserializeObject<LoginData>(loginJson);

        PlayerData = new PlayerDataAPI(this);
        Market = new MarketAPI(this, loginData.user_id);
        Inventory = new InventoryAPI(this, loginData.user_id);
        Quest = new QuestAPI(this, loginData.user_id);
        Dialogue = new DialogueAPI(this);

        PlayerData.RequestLoadPlayerData(loginData.user_id);
    }



    // ���ø����̼� ���� �� ���� ������ ����
    private void OnApplicationQuit()
    {
        CancelInvoke("AutoSaveData");
    }


    public class LoginData
    {
        public string user_id;
        public string nickname;
    }




}