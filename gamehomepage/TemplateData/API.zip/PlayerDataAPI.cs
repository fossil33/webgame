using Newtonsoft.Json;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using static APIManager;

public class PlayerDataAPI
{
    private MonoBehaviour coroutineRunner;
    private string userId;

    // �����ڸ� ���� MonoBehaviour �ν��Ͻ��� ���Թ޽��ϴ�.
    public PlayerDataAPI(MonoBehaviour runner)
    {
        this.coroutineRunner = runner;
    }


    // �÷��̾� ������ ��û
    IEnumerator RequestLoadPlayerDataCoroutine(string userId)
    {
        string url = $"{APIConstants.BASE_API_URL}/playerData/{userId}";
        using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
        {
            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    PlayerData data = JsonConvert.DeserializeObject<PlayerData>(webRequest.downloadHandler.text);
                    Debug.Log("�÷��̾� ������ �ε� ����: " + data.id);
                    DataManager.Instance.LoadPlayerData(data);


                    //LoadingScene.LoadScene("Main");
                }
                catch (JsonException ex)
                {
                    Debug.LogError("JSON ������ȭ ����: " + ex.Message);
                }
            }
            else
            {
                Debug.LogError($"�÷��̾� ������ �ε� ����: {webRequest.error}");
            }
        }
    }

    //�÷��̾� ������ ����
    IEnumerator SavePlayerDataCourotine(PlayerData data)
    {
        string json = JsonConvert.SerializeObject(data);

        string url = $"{APIConstants.BASE_API_URL}/playerData/{userId}";

        using (UnityWebRequest webRequest = new UnityWebRequest(url, "POST"))
        {
            byte[] bodyRaw = Encoding.UTF8.GetBytes(json);
            webRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
            webRequest.downloadHandler = new DownloadHandlerBuffer();
            webRequest.SetRequestHeader("Content-Type", "application/json");

            yield return webRequest.SendWebRequest();

            if (webRequest.result == UnityWebRequest.Result.Success)
            {
                Debug.Log($"Client {userId} : ������ ���� �Ϸ�");
            }
            else
            {
                Debug.LogError("������ ���� ����: " + webRequest.error);
            }
        }

    }


    public void RequestLoadPlayerData(string userId)
    {
        this.userId = userId;
        coroutineRunner.StartCoroutine(RequestLoadPlayerDataCoroutine(userId));
    }

    public void RequestSavePlayerData(PlayerData data)
    {
        coroutineRunner.StartCoroutine(SavePlayerDataCourotine(data));
    }



}
