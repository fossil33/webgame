// server.js (Node.js)


const express = require('express');
const cors = require('cors');
const http = require('http');
const path = require('path');
const fs = require('fs'); // [추가] 파일 시스템 모듈 불러오기

const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server, {
    cors: {
        origin: "*", // 모든 출처 허용 (개발용)
        methods: ["GET", "POST"]
    }
});


app.use(cors()); 
app.use(express.json());



let questData;
let dialogueData;




try {
    // 서버가 시작될 때 동기적으로 파일을 읽어옵니다. (시작 시 한 번만 실행되므로 sync 사용 가능)
    const questJson = fs.readFileSync(path.join(__dirname, 'gameData', 'questData.json'), 'utf8');
    const dialogueJson = fs.readFileSync(path.join(__dirname, 'gameData', 'dialogue.json'), 'utf8');
    
    questData = JSON.parse(questJson);
    dialogueData = JSON.parse(dialogueJson);

    console.log("Game data (quests, dialogues) loaded successfully.");
} catch (error) {
    console.error("Error loading game data:", error);
    // 데이터 로드 실패 시 서버를 종료하거나 비상 조치를 취할 수 있습니다.
    process.exit(1);
}

const players = {
    'editor_user_id': {
        id: 'editor_user_id',
        nickname: '에디터_테스터',
        currentHp: 100,
        maxHp: 100,
        level: 1,
        exp: 1,
        speed: 3,
        defense: 5,
        damage: 1,
        dead: false,
        gold: 55500,
        
        position: { x: 330, y: 6, z: 300 },
        rotation: { x: 0, y: 0, z: 0},

        inventory: [
            {
                slotIndex: 0,
                slotType: 0, // 0 = Equipment
                itemId: 101,
                itemSpec: {
                  damage: 15,
                  defense: 0,
                  speed: 0,
                  hp: 0
                },
                itemCount: 1
            },
                        {
                slotIndex: 1,
                slotType: 0, // 0 = Equipment
                itemId: 201,
                itemSpec: {
                  damage: 0,
                  defense: 5,
                  speed: 0,
                  hp: 0
                },
                itemCount: 1
            },
            {
                slotIndex: 1,
                slotType: 1, // 0 = Equipment
                itemId: 1,
                itemSpec: {
                  damage: 0,
                  defense: 0,
                  speed: 0,
                  hp: 0
                },
                itemCount: 3
            }

        ]
    },
        'editor_user_id2': {
        id: 'editor_user_id2',
        nickname: '에디터_테스터2',
        currentHp: 80,
        maxHp: 100,
        level: 1,
        exp: 1,
        speed: 3,
        defense: 5,
        damage: 1,
        dead: false,
        gold: 55500,
        

        position: { x: 330, y: 6, z: 300 },
        rotation: { x: 0, y: 0, z: 0},

        inventory: [
            {
                slotIndex: 0,
                slotType: 0, // 0 = Equipment
                itemId: 101,
                itemSpec: {
                  damage: 15,
                  defense: 0,
                  speed: 0,
                  hp: 0
                },
                itemCount: 1
            },
                        {
                slotIndex: 1,
                slotType: 0, // 0 = Equipment
                itemId: 201,
                itemSpec: {
                  damage: 0,
                  defense: 5,
                  speed: 0,
                  hp: 0
                },
                itemCount: 1
            },
                        {
                slotIndex: 1,
                slotType: 1, // 0 = Equipment
                itemId: 1,
                itemSpec: {
                  damage: 0,
                  defense: 0,
                  speed: 0,
                  hp: 0
                },
                itemCount: 3
            }

        
        ]
    }
    
};

// [추가] 현재 접속 중인 플레이어 목록을 관리할 객체
const onlinePlayers = {};

// [추가] ID 매핑을 위한 객체
const socketIdToUserId = {};
const userIdToSocketId = {};

io.on('connect', (socket) => {
    console.log(`[Socket.IO] A user connected with temporary id: ${socket.id}`);

    // 클라이언트로부터 userId를 받는 초기화 이벤트
    socket.on('initialize', (userId) => {
        // 1. 전체 유저 DB(`players`)에 해당 유저가 있는지 확인
        if (players[userId]) {
            // "Initializing user" 로그가 여기서 출력됩니다.
            console.log(`[Socket.IO] Initializing user. Mapping ${socket.id} to ${userId}`);
            
            // 2. ID 매핑 저장
            socketIdToUserId[socket.id] = userId;
            userIdToSocketId[userId] = socket.id;

            // 3. DB에서 유저 정보를 가져와 '온라인 플레이어 목록'에 추가
            const newPlayer = { ...players[userId] };
            newPlayer.id = userId; // ID 일관성 유지
            onlinePlayers[userId] = newPlayer;

            // 5. 다른 모든 클라이언트에게 '새로운 플레이어의 등장'을 알림
            const initialPlayerData  = {
                id: newPlayer.id,
                position: newPlayer.position,
                rotation: newPlayer.rotation
            };
            socket.emit('initializeComplete', initialPlayerData);
            socket.broadcast.emit('newPlayer', initialPlayerData );

        } else {
            console.log(`[Socket.IO] User with ID ${userId} not found.`);
        }
    }); // <-- 'initialize' 이벤트 리스너는 여기서 끝납니다.


    // [새로 추가] 클라이언트가 씬 로딩 완료를 알렸을 때
    socket.on('LoadSceneComplete', () => {
        const userId = socketIdToUserId[socket.id];
        if (!userId || !onlinePlayers[userId]) {
            console.log(`[Socket.IO] User for socket ${socket.id} not found for LoadSceneComplete.`);
            return;
        }

        console.log(`[Socket.IO] User ${userId} has loaded the scene. Sending current players list.`);

        // 이 클라이언트를 제외한 다른 플레이어 목록을 전송
        const otherOnlinePlayers = Object.values(onlinePlayers).filter(p => p.id !== userId);
        const simplifiedPlayers = otherOnlinePlayers.map(player => ({
            id: player.id,
            position: player.position,
            rotation: player.rotation
        }));
        
        // 요청한 클라이언트에게만 'currentPlayers' 데이터를 보냅니다.
        socket.emit('currentPlayers', { players: simplifiedPlayers });
    });


// 'playerMovement' 이벤트 리스너 (모든 단계 로그 출력 버전)
socket.on('playerMovement', (movementData) => {
    // 1단계: 이벤트 수신 및 데이터 타입 확인
    console.log(`\n[로그 1] playerMovement 이벤트 수신됨 (소켓 ID: ${socket.id})`);


    const userId = socketIdToUserId[socket.id];

    // 2단계: userId 존재 여부 확인
    if (!userId) {
        console.error(`[오류!] 소켓 ID(${socket.id})에 해당하는 userId를 찾을 수 없습니다.`);
        return;
    }
    console.log(`[로그 2] userId '${userId}'를 성공적으로 찾음.`);

    // 3단계: 데이터 유효성 검사 (if 조건문 진입 전 상태 확인)
    console.log(`[로그 3] 데이터 유효성 검사를 시작합니다.`);
    console.log(`       ├ onlinePlayers['${userId}'] 존재 여부: ${!!onlinePlayers[userId]}`);
    console.log(`       ├ movementData 존재 여부: ${!!movementData}`);
    
    // movementData가 객체인지 먼저 확인하여 오류 방지
    if (typeof movementData === 'object' && movementData !== null) {
        console.log(`       ├ movementData.position 존재 여부: ${!!movementData.position}`);
        console.log(`       └ movementData.rotation 존재 여부: ${!!movementData.rotation}`);
    } else {
        console.log(`       └ movementData가 객체가 아니라서 내부 속성을 확인할 수 없음.`);
    }

    if (onlinePlayers[userId] && movementData && movementData.position && movementData.rotation) {
        console.log(`[로그 4] 데이터 유효성 검사 통과. 상태 업데이트를 시작합니다.`);

        // 5단계: onlinePlayers 객체 업데이트
        onlinePlayers[userId].position = movementData.position;
        onlinePlayers[userId].rotation = movementData.rotation;
        console.log(`[로그 5] onlinePlayers['${userId}'] 상태 업데이트 완료.`);

        // 6단계: players 객체 존재 확인 및 업데이트
        if (players[userId]) {
            players[userId].position = movementData.position;
            players[userId].rotation = movementData.rotation;
            console.log(`[로그 6] players['${userId}'] 상태 업데이트 완료.`);
        } else {
             console.warn(`[경고!] players 객체에 userId '${userId}'가 존재하지 않아 DB 업데이트를 건너뜁니다.`);
        }

        // 7단계: 브로드캐스트 실행
        const broadcastData = {
            id: userId,
            position: onlinePlayers[userId].position,
            rotation: onlinePlayers[userId].rotation
        };
        socket.broadcast.emit('updatePlayerMovement', broadcastData);
        console.log(`[성공!] 브로드캐스트 완료.`);

    } else {
        // 유효성 검사 실패 시
        console.warn(`[경고!] 데이터 유효성 검사 실패. userId '${userId}'의 이동 데이터 처리를 무시합니다.`);
    }
});


// 'playerAnimation' 이벤트 리스너
socket.on('playerAnimation', (animData) => {
    const userId = socketIdToUserId[socket.id];
    if (!userId) { return; }

    // 데이터가 유효한지 간단히 확인 (필요에 따라 더 상세하게)
    if (animData && typeof animData.vertical !== 'undefined' && typeof animData.horizontal !== 'undefined') {
        
        // 받은 데이터를 그대로 다른 클라이언트들에게 브로드캐스트합니다.
        // id를 추가하여 누가 보낸 애니메이션인지 알려줍니다.
        const broadcastData = {
            id: userId,
            vertical: animData.vertical,
            horizontal: animData.horizontal,
        };

        socket.broadcast.emit('updatePlayerAnimation', broadcastData);
    }
});

    // 'disconnect' 이벤트 리스너
    socket.on('disconnect', () => {
        const userId = socketIdToUserId[socket.id];
        if (userId) {
            console.log(`[Socket.IO] A user disconnected: ${userId}`);
            
            delete onlinePlayers[userId];
            delete userIdToSocketId[userId];
            delete socketIdToUserId[socket.id];
            
            io.emit('playerDisconnected', userId);
        }
    });
});


// ====================================================================
// 사용자별 퀘스트 진행 데이터 (questID 키를 숫자로 변경)
// ====================================================================
let userQuestStatuses = {
    'editor_user_id2': []
};

// 마켓 아이템 저장소
// marketId를 키로 사용
let marketIdCounter = 0;
const marketItems = {}; 
// 구조: { marketId: { userId, ItemId, itemData, itemCount, price } }


// 루트 경로에 접속 시 간단한 메시지
app.get('/playerData/:userId', (req, res) => {
    const { userId } = req.params;
    console.log(userId);
    const player = players[userId];
    if (player) {
        res.status(200).json(player); // 200 OK와 JSON 데이터를 응답
    } else {
        res.status(404).send('플레이어 정보를 찾을 수 없습니다.'); // 404 Not Found
    }
});

// POST 요청을 처리하여 데이터를 저장하는 라우터
app.post('/playerData/:userId', (req, res) => {
    // 1. URL 파라미터에서 userId를 가져옵니다.
    const { userId } = req.params; 
    
    // 2. 요청의 body에서 업데이트할 플레이어 데이터를 가져옵니다.
    const newPlayerData = req.body;

    console.log(`[${userId}] 데이터 저장 요청 받음.`);
    // console.log('받은 데이터:', newPlayerData);

    // 3. players 객체에 해당 userId를 가진 플레이어가 있는지 확인합니다.
    if (players[userId]) {
        // 4. 데이터 저장 (기존 데이터를 새로운 데이터로 업데이트)
        // 참고: {...기존객체, ...새객체} 문법은 기존 데이터 위에 새 데이터를 덮어쓰는 스마트한 방법입니다.
        // 클라이언트가 일부 데이터만 보내도 기존 값은 유지되고, 받은 값만 업데이트됩니다.
        players[userId] = { ...players[userId], ...newPlayerData };

        console.log(`[${userId}] 데이터 저장 완료.`);
        // console.log('업데이트된 데이터:', players[userId]);

        // 5. 클라이언트에 성공적으로 저장되었음을 알립니다.
        res.status(200).json({ success: true, message: 'Player data saved successfully.' });
    } else {
        // 6. 해당 플레이어가 존재하지 않으면 404 에러를 보냅니다.
        console.warn(`[${userId}] 존재하지 않는 플레이어에 대한 저장 시도.`);
        res.status(404).json({ success: false, message: 'Player not found.' });
    }
});

//인벤토리 가져오기
app.get('/playerData/inventory/:userId', (req, res) => {
    console.debug('인벤토리 가져오기 시도');
    const { userId } = req.params;
    const player = players[userId];

    if (player) {
        // 인벤토리 데이터만 JSON 형태로 응답합니다.
        // 클라이언트의 InventoryResponse 클래스와 구조가 일치해야 합니다.
        console.debug({ inventory: player.inventory });
        res.status(200).json({ inventory: player.inventory });
    } else {
        res.status(404).json({ message: '플레이어 정보를 찾을 수 없습니다.' });
    }
});

app.post('/playerData/inventory/:userId', (req, res) => {
    // 1. URL 파라미터와 요청 바디 추출
    const { userId } = req.params;
    const body = req.body;
    
    // 2. 플레이어 유효성 검사
    const player = players[userId];
    if (!player) {
        return res.status(404).json({ success: false, message: '플레이어를 찾을 수 없습니다.' });
    }

    // 3. 요청 데이터 분석 및 로직 분기
    // 클라이언트가 hasItem 필드를 보냈고, 그것이 false라면 '제거' 로직으로 판단
    if (body.hasItem === false) {
        const { slotIndex, slotType } = body;

        if (slotIndex === undefined || slotType === undefined) {
            return res.status(400).json({ success: false, message: '잘못된 요청입니다. 슬롯 정보가 누락되었습니다.' });
        }

        // hasItem이 false이면, 해당 슬롯을 배열에서 제거
        player.inventory = player.inventory.filter(item => 
            !(item.slotIndex === slotIndex && item.slotType === slotType)
        );
        console.log(`인벤토리 슬롯 초기화(제거) 완료: slotIndex ${slotIndex}, slotType ${slotType}`);
        return res.status(200).json({ success: true, message: '인벤토리 슬롯 초기화 성공' });
    }

    // 클라이언트가 slotIndex를 보냈다면 '업데이트' 로직으로 판단
    if (body.slotIndex !== undefined && body.slotType !== undefined) {
        const { slotIndex, slotType } = body;
        const inventoryItem = player.inventory.find(item => 
            item.slotIndex === slotIndex && item.slotType === slotType
        );

        if (inventoryItem) {
            // 기존 아이템이 있을 경우, 요청받은 데이터로 업데이트
            Object.assign(inventoryItem, body);
            console.log(`인벤토리 슬롯 업데이트 완료: ${JSON.stringify(body)}`);
            return res.status(200).json({ success: true, message: '인벤토리 업데이트 성공' });
        } else {
            // 새로운 아이템일 경우, 배열에 추가
            player.inventory.push(body);
            console.log(`새로운 아이템 추가 완료: ${JSON.stringify(body)}`);
            return res.status(201).json({ success: true, message: '새로운 아이템 생성 성공' });
        }
    } else {
        // slotIndex가 없다면 '새로운 아이템 생성' 로직으로 판단
        const newItem = body;
        player.inventory.push(newItem);
        console.log(`새로운 아이템 추가 완료: ${JSON.stringify(newItem)}`);
        return res.status(201).json({ success: true, message: '새로운 아이템 생성 성공' });
    }
});


// 아이템 등록 취소 (DELETE 요청 핸들러)
app.delete('/market/items/:userId/:marketId', (req, res) => {
    console.log("아이템 삭제 요청 시도");
    const { userId, marketId } = req.params;

    // marketId가 정수인지 확인
    const parsedMarketId = parseInt(marketId, 10);
    if (isNaN(parsedMarketId)) {
        return res.status(400).json({ success: false, message: '잘못된 marketId 형식입니다.' });
    }

    const marketItem = marketItems[parsedMarketId];

    // 1. 해당 marketId의 아이템이 존재하는지 확인
    if (!marketItem) {
        return res.status(404).json({ success: false, message: '해당 마켓 아이템을 찾을 수 없습니다.' });
    }

    // 2. 요청을 보낸 사용자가 아이템의 소유자인지 확인
    if (marketItem.userId !== userId) {
        return res.status(403).json({ success: false, message: '아이템을 삭제할 권한이 없습니다.' });
    }

    // 3. 아이템 삭제 전, 클라이언트에게 응답할 데이터 준비
    const responseData = {
        success: true,
        message: '아이템 등록이 취소되었습니다.',
        marketId: parsedMarketId,
        ItemId: marketItem.ItemId,
        ItemCount: marketItem.itemCount,
        price: marketItem.price,
        spec: marketItem.itemSpec,
    };
    
    // 4. 데이터 저장소에서 아이템 삭제
    delete marketItems[parsedMarketId];

    console.log(`마켓 아이템 삭제 완료: marketId=${parsedMarketId}`);

    // 5. 클라이언트에게 성공 응답 전송
    return res.status(200).json(responseData);
});



// 판매 목록 조회
app.get('/market/items', (req, res) => {
  console.log("아이템 목록 가져오기 시도");
  // marketItems 객체를 배열 형태로 변환
  const items = Object.entries(marketItems).map(([marketId, item]) => ({
    marketId: parseInt(marketId),
    ItemId: item.ItemId,
    ItemCount: item.itemCount,
    price: item.price
  }));
  console.log(items);
  return res.status(200).json(items);
});

// 개별 판매 목록 조회
app.get('/market/items/:userId', (req, res) => {
    console.log("아이템 목록 가져오기 시도");
    const { userId } = req.params; // 1. URL 파라미터에서 userId를 가져옵니다.
    
    // 2. marketItems 객체를 순회하며 userId가 일치하는 아이템만 필터링합니다.
      const userItems = Object.entries(marketItems)
      .filter(([marketId, item]) => item.userId === userId)
      .map(([marketId, item]) => ({
      marketId: parseInt(marketId, 10), // 문자열 키를 정수로 변환
      ItemId: item.ItemId,
      ItemCount: item.itemCount,
      price: item.price,
      itemSpec: item.itemSpec // spec도 함께 추가
    }));

    console.log(userItems);
    
    if (userItems.length === 0) {
        // 4. 조회된 아이템이 없을 경우, 404 Not Found 상태를 반환합니다.
        console.log(`유저 ID ${userId}의 아이템을 찾을 수 없습니다.`);
        return res.status(404).json({ message: '해당 유저의 아이템이 존재하지 않습니다.' });
    }

    return res.status(200).json(userItems);
});


// 아이템 등록 POST 요청 핸들러
app.post('/market/items', (req, res) => {
    console.log("아이템 등록 시도");
    console.log(req.body);
    // req.body를 통해 JSON 데이터 접근 (클라이언트에서 보낸 객체)
    // 클라이언트에서 보낼 JSON 데이터 예시: { "userId": "user123", "itemId": "item001", "itemCount": 5, "price": 100 }
    const { userId, ItemId, itemSpec, itemCount, price } = req.body; // 구조 분해 할당으로 데이터 추출

    console.log(`수신된 데이터:`);
    console.log(`User ID: ${userId}`);
    console.log(`itemId: ${ItemId}`);
    console.log(`itemData: ${itemSpec}`);
    console.log(`ItemCount: ${itemCount}`); // 클라이언트에서 보낸 ItemCount
    console.log(`Price: ${price}`);

    // 서버 측 로직: 여기서 데이터베이스 저장, 유효성 검사 등을 수행합니다.
    // 예시: 간단한 유효성 검사
    if (!userId || !itemSpec || typeof itemCount === 'undefined' || typeof price === 'undefined') {
        return res.status(400).json({ success: false, message: "필수 데이터 누락" });
    }


  // 새로운 marketId 발급
  const marketId = marketIdCounter++;

  // 마켓 DB에 저장
  marketItems[marketId] = {
    userId,
    ItemId,
    itemSpec: itemSpec,   // 클라이언트에서 보낸 ItemData 그대로 저장
    itemCount: parseInt(itemCount),
    price: parseInt(price),
  };

  console.log(`아이템 등록됨 marketId=${marketId} : ${JSON.stringify(marketItems[marketId])}`);

  return res.status(200).json({
    success: true,
    message: "아이템 등록 성공!",
    ItemId,
    marketId,
    ItemCount: itemCount,
    price,
  });
});


//아이템 구매
app.get('/market/buy', (req,res) =>{
  const { userId, marketId, count } = req.query;

  const purchaseCount = parseInt(count, 10);
  if (!userId || !marketId || isNaN(purchaseCount)) {
    return res.status(200).json({ success: false, message: "잘못된 요청입니다." });
  }

  const marketItem = marketItems[marketId];
  if (!marketItem) {
    return res.status(200).json({ success: false, message: "해당 마켓 아이템이 없습니다." });
  }

  if (marketItem.itemCount < purchaseCount) {
    return res.status(200).json({ success: false, message: "아이템 개수가 부족합니다." });
  }

  // 금액 차감
  const totalPrice = marketItem.price * purchaseCount;
  if (players[userId].gold < totalPrice) {
    return res.status(200).json({ success: false, message: "골드가 부족합니다." });
  }
  players[userId].gold -= totalPrice;

  // 수량 감소
  marketItem.itemCount -= purchaseCount;
  if(marketItem.itemCount <= 0){
    delete marketItems[marketId];
  }

  console.log(
    `${userId}가 marketId : ${marketId}에서 ${purchaseCount}개 구매 -> 남은 수량: ${marketItem.itemCount}`
  );

  return res.status(200).json({
    success: true,
    message: "구매 성공",
    marketId: marketId,
    ItemId: marketItem.ItemId,
    spec: marketItem.itemSpec, 
    purchasedItemCount: purchaseCount,
    remainingItemCount: marketItem.itemCount,
    gold: players[userId].gold,
  });
});



// --- 대화 정보 가져오기 API ---
// GET /dialogue
app.get('/dialogue', (req, res) => {
    // 요청이 들어왔는지 서버 로그에 기록
    console.log('Request received for all dialogue data');
    
    // 클라이언트가 Dialogue[] 배열을 기대하므로, 
    // dialogueData 배열을 그대로 JSON 형태로 응답합니다.
    res.status(200).json(dialogueData);
});

// 퀘스트 정보 가져오기 API
app.get('/quest/:userId', (req, res) => {
    const userId = req.params.userId;
    console.log(`Request received for quest data for user: ${userId}`);
    
    // 해당 유저의 퀘스트 상태 데이터를 가져옵니다.
    // 만약 해당 유저의 데이터가 없으면 빈 배열을 보냅니다.
    const statusesForUser = userQuestStatuses[userId] || [];

    // 클라이언트의 QuestDataList 클래스 구조에 맞춰 JSON 응답을 구성합니다.
    res.status(200).json({
        questData: questData,           // 'quests' -> 'questData'로 키 이름 변경
        questStatuses: statusesForUser  // 'questStatuses' 키와 함께 유저의 상태 정보 추가
    });
});


// 퀘스트 정보 저장/업데이트 API
app.post('/quest/:userId', (req, res) => {
    // 1. 요청으로부터 userId와 questStatus 데이터 추출
    const userId = req.params.userId;
    const newQuestStatus = req.body; // 클라이언트에서 보낸 QuestStatus JSON 데이터

    console.log(`Request received to save quest data for user: ${userId}`);
    console.log('Received data:', newQuestStatus);

    // 2. 데이터 유효성 검사 (questId가 없는 등 비정상적인 데이터 방지)
    if (!newQuestStatus || !newQuestStatus.questId) {
        return res.status(400).json({ message: 'Bad Request: Invalid quest data received.' });
    }

    // 3. 해당 유저의 퀘스트 목록 가져오기 (없으면 새로 생성)
    if (!userQuestStatuses[userId]) {
        userQuestStatuses[userId] = [];
    }
    const statusesForUser = userQuestStatuses[userId];

    // 4. 기존에 저장된 퀘스트인지 확인 (questId를 기준으로 검색)
    const questIndex = statusesForUser.findIndex(q => q.questId === newQuestStatus.questId);

    // 5. 찾은 인덱스에 따라 퀘스트 업데이트 또는 새로 추가
    if (questIndex > -1) {
        // 이미 존재하는 퀘스트이면, 받은 데이터로 덮어쓰기(업데이트)
        console.log(`Updating existing quest (ID: ${newQuestStatus.questId}) for user: ${userId}`);
        statusesForUser[questIndex] = newQuestStatus;
    } else {
        // 존재하지 않는 퀘스트이면, 배열에 새로 추가
        console.log(`Adding new quest (ID: ${newQuestStatus.questId}) for user: ${userId}`);
        statusesForUser.push(newQuestStatus);
    }

    // 6. 성공 응답 전송
    res.status(200).json({ message: 'Quest status saved successfully.' });
});


const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`서버가 포트 ${PORT}에서 실행 중입니다.`);
    console.log(`http://localhost:${PORT}`);
});


